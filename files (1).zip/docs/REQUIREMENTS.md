# The SMP Launcher – Tasarım ve İşlev Protokolü v1.0

## Amaç
Yalnızca The SMP sunucusuna özel, sadece 1.21.6 sürümünü destekleyen, mod yükleme kontrolü olan, görsel olarak Minecraft doğallığına sadık, kullanıcı dostu bir launcher.

### Özellikler (Kısaca)
- Splash ekranı, yükleme animasyonu
- Sürüm kısıtlaması (1.21.6 + optifine/sodium)
- Mod yükleme izin ve kontrolleri
- Crackli kullanıcı adı ile başlatma
- Sunucuya otomatik bağlanma veya klasik Minecraft menüsüne yönlendirme