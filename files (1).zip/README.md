# The SMP Launcher

🎮 1.21.6 sürümüne özel Minecraft SMP sunucu launcher’ı.

## Özellikler
- Minecraft doğallığına sadık arayüzler
- Sadece The SMP sunucusuna bağlanabilme veya klasik menü seçimi
- Mod yükleme kontrolleri
- Crackli çalışabilme (Mojang doğrulaması olmadan)
- Responsive ve sade tasarım

## Kurulum & Çalıştırma

Java 17+ gerektirir.

```sh
javac -d out src/**/*.java
java -cp out main.Main
```

Modlar için "mods" klasörünü kullanın, OptiFine/Sodium modu etkin olmalıdır.

## Katkı & Lisans

MIT Lisanslıdır. Tasarımlar ve logo projeye özeldir.