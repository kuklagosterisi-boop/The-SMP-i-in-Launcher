package launcher;

import ui.*;

public class Launcher {
    public void run() {
        SplashScreen.showSplash(3000);
        LoadingScreen.showLoading(2500);
        MainMenu.showMenu();
    }
}