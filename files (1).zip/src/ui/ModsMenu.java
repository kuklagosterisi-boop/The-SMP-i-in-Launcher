package ui;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class ModsMenu {
    public static void showMenu() {
        JFrame modsFrame = new JFrame("Modlar");
        modsFrame.setSize(480, 340);
        modsFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(146, 174, 101));

        JLabel info = new JLabel("Aşağıda mod klasörü içeriğini görebilirsiniz.", JLabel.CENTER);
        panel.add(info, BorderLayout.NORTH);

        File modsFolder = new File("mods");
        if (!modsFolder.exists()) modsFolder.mkdirs();

        DefaultListModel<String> model = new DefaultListModel<>();
        for (File file : modsFolder.listFiles()) {
            model.addElement(file.getName());
        }
        JList<String> modsList = new JList<>(model);

        panel.add(new JScrollPane(modsList), BorderLayout.CENTER);

        JButton addBtn = new JButton("Mod Yükle...");
        addBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Mod dosyası seç (.jar)");
            int ret = chooser.showOpenDialog(modsFrame);
            if (ret == JFileChooser.APPROVE_OPTION) {
                File selected = chooser.getSelectedFile();
                selected.renameTo(new File(modsFolder, selected.getName()));
                model.addElement(selected.getName());
            }
        });
        panel.add(addBtn, BorderLayout.SOUTH);

        modsFrame.setContentPane(panel);
        modsFrame.setVisible(true);
    }
}