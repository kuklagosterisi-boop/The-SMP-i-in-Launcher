package ui;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class SetupWizard {
    public static void showWizard() {
        JFrame frame = new JFrame("Kurulum Sihirbazı - The SMP Launcher");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(500, 330);
        frame.setLocationRelativeTo(null);

        CardLayout cl = new CardLayout();
        JPanel cards = new JPanel(cl);

        // 1. HOŞ GELDİNİZ
        JPanel welcome = new JPanel(new BorderLayout());
        welcome.setBackground(new Color(130,184,131));
        JLabel lblWelcome = new JLabel("<html><center><h2>Hoş Geldiniz!</h2>The SMP Launcher'a başlamak için adımları takip edin.</center></html>", JLabel.CENTER);
        welcome.add(lblWelcome, BorderLayout.CENTER);
        JButton next1 = new JButton("Devam et >");
        welcome.add(next1, BorderLayout.SOUTH);

        // 2. SUNUCU AYARI
        JPanel connectPanel = new JPanel(new BorderLayout());
        connectPanel.setBackground(new Color(146, 174, 101));
        JCheckBox connectServer = new JCheckBox("<html>Başlangıçta sunucuya otomatik bağlan<br><small>(thesmp36.aternos.me:22722)</small></html>");
        connectServer.setSelected(true);
        connectPanel.add(connectServer, BorderLayout.CENTER);
        JButton next2 = new JButton("Devam et >");
        connectPanel.add(next2, BorderLayout.SOUTH);

        // 3. KULLANICI & SÜRÜM
        JPanel userPanel = new JPanel(new GridLayout(0,1,6,6));
        userPanel.setBackground(new Color(82, 116, 63));
        JTextField nameField = new JTextField(17);
        JComboBox<String> versionField = new JComboBox<>(new String[] {"1.21.6", "1.21.6 OptiFine", "1.21.6 Sodium"});
        userPanel.add(new JLabel("Kullanıcı Adınız:"));
        userPanel.add(nameField);
        userPanel.add(new JLabel("Sürüm Seçiniz:"));
        userPanel.add(versionField);
        JButton next3 = new JButton("Devam et >");
        userPanel.add(next3);

        // 4. MODLAR
        JPanel modPanel = new JPanel(new BorderLayout());
        modPanel.setBackground(new Color(107, 184, 78));
        JLabel modLabel = new JLabel("<html>Ek modları (OptiFine/Sodium) kullanacak mısınız?<br>Modları kurmak için 'mods' klasörünü kullanabilirsiniz.</html>", JLabel.CENTER);
        modPanel.add(modLabel, BorderLayout.CENTER);
        JButton finishBtn = new JButton("Kurulumu Tamamla");
        modPanel.add(finishBtn, BorderLayout.SOUTH);

        // KARTLAR
        cards.add(welcome, "welcome");
        cards.add(connectPanel, "connect");
        cards.add(userPanel, "user");
        cards.add(modPanel, "mod");

        frame.setContentPane(cards);

        // Adım geçişleri
        next1.addActionListener(e -> cl.show(cards, "connect"));
        next2.addActionListener(e -> cl.show(cards, "user"));
        next3.addActionListener(e -> cl.show(cards, "mod"));

        // Sihirbaz tamamlama
        finishBtn.addActionListener(e -> {
            // Ayarları kaydet (gerçekte config dosyasına yazılabilir)
            String username = nameField.getText().trim();
            String version = (String) versionField.getSelectedItem();
            boolean serverAuto = connectServer.isSelected();

            // mods klasörü oluştur
            File modsFolder = new File("mods");
            if (!modsFolder.exists()) modsFolder.mkdirs();

            JOptionPane.showMessageDialog(frame,
                "<html>Kurulum Tamamlandı!<br>"
                + "Kullanıcı adı: <b>" + username + "</b><br>"
                + "Sürüm: <b>" + version + "</b><br>"
                + "Sunucuya otomatik bağlan: <b>" + (serverAuto ? "Evet" : "Hayır") + "</b>"
                + "<br><br>Launcher başlatılıyor!</html>");

            frame.dispose();
            MainMenu.showMenu(); // Sihirbaz sonrası ana menüye yönlendir
        });

        cl.show(cards, "welcome");
        frame.setVisible(true);
    }
}