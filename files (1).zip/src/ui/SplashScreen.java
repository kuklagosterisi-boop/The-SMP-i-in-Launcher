package ui;

import javax.swing.*;
import java.awt.*;

public class SplashScreen {
    public static void showSplash(int durationMs) {
        JFrame splash = new JFrame();
        splash.setUndecorated(true);
        splash.setSize(460, 260);
        splash.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(51, 47, 46));
        panel.setLayout(new BorderLayout());

        JLabel logo = new JLabel(new ImageIcon("assets/logo.png"));
        logo.setHorizontalAlignment(JLabel.CENTER);
        panel.add(logo, BorderLayout.CENTER);

        splash.add(panel);
        splash.setVisible(true);

        try {
            Thread.sleep(durationMs);
        } catch (InterruptedException ignored) {}

        splash.setVisible(false);
        splash.dispose();
    }
}