package ui;

import javax.swing.*;
import java.awt.*;

public class SettingsMenu {
    public static void showMenu(JFrame parent) {
        JDialog dialog = new JDialog(parent, "Ayarlar", true);
        dialog.setSize(320,220);
        dialog.setLocationRelativeTo(parent);

        JPanel panel = new JPanel(new GridLayout(0,1));
        panel.setBackground(new Color(130,184,131));

        JCheckBox autoConnect = new JCheckBox("Başlarken sunucuya otomatik bağlan");
        JCheckBox classicMenu = new JCheckBox("Başlarken Minecraft ana menüsüne götür");
        autoConnect.setSelected(true);

        ButtonGroup group = new ButtonGroup();
        group.add(autoConnect);
        group.add(classicMenu);

        panel.add(autoConnect);
        panel.add(classicMenu);

        dialog.setContentPane(panel);
        dialog.setVisible(true);
    }
}