package ui;

import javax.swing.*;
import java.awt.*;

public class LoadingScreen {
    public static void showLoading(int durationMs) {
        JFrame load = new JFrame("The SMP Launcher");
        load.setUndecorated(true);
        load.setSize(460, 260);
        load.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(107, 184, 78));
        panel.setLayout(new BorderLayout());

        JLabel loading = new JLabel("Yükleniyor...", JLabel.CENTER);
        loading.setFont(new Font("Arial", Font.BOLD, 28));
        loading.setForeground(new Color(51, 47, 46));
        panel.add(loading, BorderLayout.CENTER);

        // Basit dönen progress simgesi
        JProgressBar bar = new JProgressBar();
        bar.setIndeterminate(true);
        panel.add(bar, BorderLayout.SOUTH);

        load.add(panel);
        load.setVisible(true);
        try {
            Thread.sleep(durationMs);
        } catch (InterruptedException ignored) {}
        load.setVisible(false);
        load.dispose();
    }
}