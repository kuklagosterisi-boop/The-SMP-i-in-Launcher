// ...
gc.gridy++;
JButton wizardBtn = new JButton("Kurulum Sihirbazı");
wizardBtn.setFont(new Font("Arial", Font.PLAIN, 20));
wizardBtn.addActionListener(e -> {
    frame.dispose();
    SetupWizard.showWizard();
});
mainPanel.add(wizardBtn, gc);
// ...